import java.util.Scanner;
import java.io.File;
import java.math.BigDecimal;

public class SalesTax{

    public static void main(String[] args) throws Exception{
        String filename = args[0];
		Scanner scan = new Scanner(new File(filename));

        Cart c = new Cart();
        CalcTax calculate = new CalcTax();
        Tax basic = new Tax("basic tax", "0.1");
        Tax imported = new Tax("import tax", "0.05");
        calculate.addTax("basic", basic);
        calculate.addTax("imported", imported);

        while(scan.hasNext()){
            BigDecimal quantity = new BigDecimal(scan.nextInt());
            String line = scan.nextLine();
            String[] split = line.split("\\sat\\s");
            Product p = new Product(split[0].substring(1), split[1]);
            c.add(p, quantity, calculate);
        }

        c.print();

		scan.close();
    }

}
